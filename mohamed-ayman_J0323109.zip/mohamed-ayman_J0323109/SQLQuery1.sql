create database task_managment
create table users
(
user_ID int primary key,
user_Name nvarchar (50),
Password nvarchar (100),
user_Role nvarchar (50)check (user_Role in ('employee','manager'))
)
create table tasks
(
task_ID int primary key,
title nvarchar (50),
description nvarchar (50),
status nvarchar (50)check(status in ('completed','pending','in progress'))
)
