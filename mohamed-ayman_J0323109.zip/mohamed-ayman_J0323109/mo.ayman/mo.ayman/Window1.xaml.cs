﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace mo.ayman
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        private task_managmentEntities context = new task_managmentEntities();
        public Window1()
        {
            InitializeComponent();
            load();
            load2();
        }
        public void load()
        {
            grid1.ItemsSource = context.tasks.Where(t => t.status == "pending" || t.status == "in progress").ToList();
        }
        public void load2()
        {
            grid2.ItemsSource = context.tasks.Where(t => t.status == "completed").ToList();
        }

        private void grid2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //if (grid1.SelectedItem is task selected)
            //{
            //    cmbox.Text = selected.status;
            //}
        }
        private void grid1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (grid1.SelectedItem is task selected)
            {
                taskid.Text = selected.task_ID.ToString();
                cmbox.Text = selected.status;
            }
        }
        private void save_Click(object sender, RoutedEventArgs e)
        {
            if (grid1.SelectedItem is task selectedtask)
            {
                selectedtask.status = cmbox.Text;
                context.SaveChanges();
                load();
                load2();
            }
          

        }

        private void grid2_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {
            
        }

        private void save_Click_1(object sender, RoutedEventArgs e)
        {
            if (grid1.SelectedItem is task selectedtask)
            {
                selectedtask.status = cmbox.Text;
                context.SaveChanges();
                load();
                load2();
                clear();
            }
        }
        private void clear()
        {
            taskid.Clear();
           
        }
    }
}

