﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace mo.ayman
{
    /// <summary>
    /// Interaction logic for Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        private task_managmentEntities context=new task_managmentEntities();
        task task = new task();
        public Window2()
        {
            InitializeComponent();
            load();
            
        }
        public void load()
        {
            taskgrid.ItemsSource = context.tasks.ToList();
        }

        private void add_Click(object sender, RoutedEventArgs e)
        {
            var x = new task
            {
                task_ID = Convert.ToInt32(taskid.Text),
                title = title.Text,
                description = descreption.Text,
                status = cmbox.Text,
            };
            context.tasks.Add(x);
            context.SaveChanges();
            load();
            clear();
        }

        private void edit_Click(object sender, RoutedEventArgs e)
        {
            if (taskgrid.SelectedItem is task selectedtask)
            {
                selectedtask.task_ID = Convert.ToInt32(taskid.Text);
                selectedtask.title = title.Text;
                selectedtask.description = descreption.Text;
                selectedtask.status = cmbox.Text;
                context.SaveChanges();
                load();
                clear();
            }
        }

        private void delete_Click(object sender, RoutedEventArgs e)
        {
            if (taskgrid.SelectedItem is task selectedtask)
            {
                context.tasks.Remove(selectedtask);
                context.SaveChanges();
                load();
                clear();
            }
        }

        private void taskgrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (taskgrid.SelectedItem is task selectedtask)
            {
                task = selectedtask;
                taskid.Text = selectedtask.task_ID.ToString();
                title.Text = selectedtask.title;
                descreption.Text = selectedtask.description;
                cmbox.Text = selectedtask.status;
            }
        }
        private void clear()
        {
            taskid.Clear();
            title.Clear();
            descreption.Clear();
            cmbox.Items.Clear();
        }
    }
}
